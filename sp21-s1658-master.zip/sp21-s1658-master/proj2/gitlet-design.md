# Gitlet Design Document

**Name**: Jiayang Xing

## Classes and Data Structures
## Persistence
**CWD

*****GITLET_DIR

************stageFolder

************commitFolder

************blobFolder



### Main
* i add exitWithError method in util.java (just like what we use in lab6)

### Commit

#### Intance Variables

1. message: contain the message of commit
2. timestamp: time when the commit was created
3. parent: the parent commit of the commit object

### repository







#### Fields

1. Field 1
2. Field 2


## Algorithms



##problem

#### small error
* in util.java two join method explaintion have error so i just delet them
  
  /** Return the concatentation of FIRST and OTHERS into a File designator,
    *  analogous to the {@link java.nio.file.Paths.#get(String, String[])}
    *  method. */

    /** Return the concatentation of FIRST and OTHERS into a File designator,
    *  analogous to the {@link java.nio.file.Paths.#get(String, String[])}
    *  method. */
